###--- >>> `isIdCurrent' <<<----- Check whether a database handle object is valid or not

	## alias	 help(isIdCurrent)

##___ Examples ___:
##Don't run: 
##D cursor <- dbSendQuery(con, sql.statement)
##D isIdCurrent(cursor)


## Keywords: 'interface', 'database'.


