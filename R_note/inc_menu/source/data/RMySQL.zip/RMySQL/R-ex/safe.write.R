###--- >>> `safe.write' <<<----- Write a data.frame avoiding exceeding memory limits

	## alias	 help(safe.write)

##___ Examples ___:
##Don't run: 
##D    ctr.file <- file("dump.sqloader", "w")
##D    safe.write(big.data, file = ctr.file, batch = 25000)


## Keywords: 'internal'.


