###--- >>> `dbApply' <<<----- Apply R/S-Plus functions to remote groups of DBMS rows (experimental)

	## alias	 help(dbApply)
	## alias	 help(dbApply.default)

##___ Examples ___:
##Don't run: 
##D ## compute quanitiles for each network agent
##D con <- dbConnect(MySQL(), group="vitalAnalysis")
##D rs <- dbSendQuery(con, 
##D              "select Agent, ip_addr, DATA from pseudo_data order by Agent")
##D out <- dbApply(rs, INDEX = "Agent", 
##D         FUN = function(x, grp) quantile(x$DATA, names=FALSE))


## Keywords: 'programming', 'interface', 'database'.


