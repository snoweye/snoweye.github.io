###--- >>> `dbObjectId-class' <<<----- Class dbObjectId

	## alias	 help(dbObjectId-class)

##___ Examples ___:
##Don't run: 
##D   pg <- dbDriver("PostgreSQL")
##D   con <- dbConnect(pg, "user", "password")
##D   is(pg, "dbObjectId")   ## True
##D   is(con, "dbObjectId")  ## True
##D   isIdCurrent(con)       ## True
##D   q("yes")
##D   \$ R 
##D   isIdCurrent(con)       ## False


## Keywords: 'classes', 'interface', 'database'.


