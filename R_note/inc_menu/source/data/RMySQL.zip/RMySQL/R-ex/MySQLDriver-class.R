###--- >>> `MySQLDriver-class' <<<----- Class MySQLDriver

	## alias	 help(MySQLDriver-class)

##___ Examples ___:
##Don't run: 
##D drv <- dbDriver("MySQL")
##D con <- dbConnect(drv, "user/password@dbname")


## Keywords: 'database', 'interface', 'classes'.


