###--- >>> `MySQLObject-class' <<<----- Class MySQLObject

	## alias	 help(MySQLObject-class)

##___ Examples ___:
##Don't run: 
##D drv <- dbDriver("MySQL")
##D con <- dbConnect(drv, dbname = "rsdbi.db")


## Keywords: 'database', 'interface', 'classes'.


