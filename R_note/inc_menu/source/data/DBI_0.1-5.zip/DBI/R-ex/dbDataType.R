### Name: dbDataType
### Title: Determine the SQL Data Type of an S object
### Aliases: dbDataType dbDataType.default
### Keywords: interface database

### ** Examples
##Don't run: 
##D ora <- dbDriver("Oracle")
##D sql.type <- dbDataType(ora, x)




