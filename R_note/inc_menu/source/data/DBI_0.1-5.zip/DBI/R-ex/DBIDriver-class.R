### Name: DBIDriver-class
### Title: Class DBIDriver
### Aliases: DBIDriver-class
### Keywords: classes database interface

### ** Examples
##Don't run: 
##D drv <- dbDriver("ODBC")
##D summary(drv)
##D dbListConnections(drv)




