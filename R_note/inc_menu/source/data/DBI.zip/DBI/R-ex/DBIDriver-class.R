###--- >>> `DBIDriver-class' <<<----- Class DBIDriver

	## alias	 help(DBIDriver-class)

##___ Examples ___:
##Don't run: 
##D drv <- dbDriver("ODBC")
##D summary(drv)
##D dbListConnections(drv)


## Keywords: 'classes', 'database', 'interface'.


