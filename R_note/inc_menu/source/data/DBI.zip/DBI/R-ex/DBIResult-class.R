###--- >>> `DBIResult-class' <<<----- Class DBIResult

	## alias	 help(DBIResult-class)

##___ Examples ___:
##Don't run: 
##D  drv <- dbDriver("Oracle")
##D  con <- dbConnect(drv, "user/password@dbname")
##D  res <- dbSendQuery(con, "select * from LASERS where prdata > '2002-05-01'")
##D  summary(res)
##D  while(dbHasCompleted(res)){
##D     chunk <- fetch(res, n = 1000)
##D     process(chunk)
##D  }


## Keywords: 'classes', 'interface', 'database'.


