###--- >>> `dbSendQuery' <<<----- Execute a statement on a given database connection

	## alias	 help(dbSendQuery)
	## alias	 help(dbGetQuery)
	## alias	 help(dbClearResult)
	## alias	 help(dbGetException)

##___ Examples ___:
##Don't run: 
##D drv <- dbDriver("MySQL")
##D con <- dbConnect(drv)
##D res <- dbSendQuery(con, "SELECT * from liv25")
##D data <- fetch(res, n = -1)


## Keywords: 'interface', 'database'.


