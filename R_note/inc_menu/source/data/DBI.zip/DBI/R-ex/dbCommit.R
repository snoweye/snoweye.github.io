###--- >>> `dbCommit' <<<----- DBMS Transaction Management

	## alias	 help(dbCommit)
	## alias	 help(dbRollback)

##___ Examples ___:
##Don't run: 
##D ora <- dbDriver("Oracle")
##D con <- dbConnect(ora)
##D rs <- dbSendQuery(con, 
##D       "delete * from PURGE as p where p.wavelength<0.03")
##D if(dbGetInfo(rs, what = "rowsAffected") > 250){
##D   warning("dubious deletion -- rolling back transaction")
##D   dbRollback(con)
##D }


## Keywords: 'interface', 'database'.


