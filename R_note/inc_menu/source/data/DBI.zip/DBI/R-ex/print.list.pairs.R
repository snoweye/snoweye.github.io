###--- >>> `print.list.pairs' <<<----- Support functions

	## alias	 help(print.list.pairs)
	## alias	 help(print)
	## alias	 help(summary)
	## alias	 help(format)

##___ Examples ___:
##Don't run: 
##D print.list.pairs(list(a =1, b = 2))


## Keywords: 'interface', 'database'.


