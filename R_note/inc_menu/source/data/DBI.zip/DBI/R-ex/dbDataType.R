###--- >>> `dbDataType' <<<----- Determine the SQL Data Type of an S object

	## alias	 help(dbDataType)
	## alias	 help(dbDataType.default)

##___ Examples ___:
##Don't run: 
##D ora <- dbDriver("Oracle")
##D sql.type <- dbDataType(ora, x)


## Keywords: 'interface', 'database'.


