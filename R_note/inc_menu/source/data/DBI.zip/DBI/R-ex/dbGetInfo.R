###--- >>> `dbGetInfo' <<<----- Database interface meta-data

	## alias	 help(dbGetDBIVersion)
	## alias	 help(dbGetInfo)
	## alias	 help(dbGetStatement)
	## alias	 help(dbGetRowCount)
	## alias	 help(dbGetRowsAffected)
	## alias	 help(dbColumnInfo)
	## alias	 help(dbHasCompleted)

##___ Examples ___:
##Don't run: 
##D drv <- dbDriver("SQLite")
##D con <- dbConnect(drv)
##D 
##D dbListTables(con)
##D 
##D rs <- dbSendQuery(con, query.sql)
##D dbGetStatement(rs)
##D dbHasCompleted(rs)
##D 
##D info <- dbGetInfo(rs)
##D names(dbGetInfo(drv))  
##D 
##D # DBIConnection info
##D names(dbGetInfo(con))
##D 
##D # DBIResult info
##D names(dbGetInfo(rs)) 


## Keywords: 'interface', 'database'.


