###--- >>> `DBIObject-class' <<<----- Class DBIObject

	## alias	 help(DBIObject-class)

##___ Examples ___:
##Don't run: 
##D drv <- dbDriver("MySQL")
##D con <- dbConnect(drv, group = "rs-dbi")
##D res <- dbSendQuery(con, "select * from vitalSuite")
##D is(drv, "DBIObject")   ## True
##D is(con, "DBIObject")   ## True
##D is(res, "DBIObject")


## Keywords: 'classes', 'interface', 'database'.


