###--- >>> `dbListTables' <<<----- List items from a remote DBMS and from objects that implement the database interface DBI.

	## alias	 help(dbListTables)
	## alias	 help(dbListFields)
	## alias	 help(dbListConnections)
	## alias	 help(dbListResults)

##___ Examples ___:
##Don't run: 
##D odbc <- dbDriver("ODBC")
##D # after working awhile...
##D for(con in dbListConnections(odbc)){
##D    dbGetStatement(dbListResults(con))
##D }


## Keywords: 'interface', 'database'.


