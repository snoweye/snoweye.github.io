###--- >>> `DBIConnection-class' <<<----- Class DBIConnection

	## alias	 help(DBIConnection-class)

##___ Examples ___:
##Don't run: 
##D ora <- dbDriver("Oracle")
##D con <- dbConnect(ora, "user/password@dbname")
##D 
##D pg <- dbDriver("PostgreSQL")
##D con <- dbConnect(pg, "user", "password")


## Keywords: 'classes'.


