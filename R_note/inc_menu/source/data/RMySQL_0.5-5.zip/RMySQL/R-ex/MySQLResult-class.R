### Name: MySQLResult-class
### Title: Class MySQLResult
### Aliases: MySQLResult-class
### Keywords: database interface classes

### ** Examples
## Not run: 
##D drv <- dbDriver("MySQL")
##D con <- dbConnect(drv, dbname = "rsdbi.db")
## End(Not run)



