### Name: MySQLObject-class
### Title: Class MySQLObject
### Aliases: MySQLObject-class
### Keywords: database interface classes

### ** Examples
## Not run: 
##D drv <- dbDriver("MySQL")
##D con <- dbConnect(drv, dbname = "rsdbi.db")
## End(Not run)



