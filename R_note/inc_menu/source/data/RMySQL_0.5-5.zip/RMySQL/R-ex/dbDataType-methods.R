### Name: dbDataType-methods
### Title: Determine the SQL Data Type of an S object
### Aliases: dbDataType-methods dbDataType,MySQLObject-method
### Keywords: interface interface database

### ** Examples
## Not run: 
##D data(quakes)
##D drv <- dbDriver("MySQL")
##D sql.type <- dbDataType(drv, quakes)
## End(Not run)



