### Name: dbGetInfo-methods
### Title: Database interface meta-data
### Aliases: dbGetInfo dbGetDBIVersion-methods dbGetStatement-methods
###   dbGetRowCount-methods dbGetRowsAffected-methods dbColumnInfo-methods
###   dbHasCompleted-methods dbGetInfo,MySQLObject-method
###   dbGetInfo,MySQLDriver-method dbGetInfo,MySQLConnection-method
###   dbGetInfo,MySQLResult-method dbGetStatement,MySQLResult-method
###   dbGetRowCount,MySQLResult-method dbGetRowsAffected,MySQLResult-method
###   dbColumnInfo,MySQLResult-method dbHasCompleted,MySQLResult-method
### Keywords: interface interface database

### ** Examples
## Not run: 
##D drv <- dbDriver("MySQL")
##D con <- dbConnect(drv, group = "wireless")
##D 
##D dbListTables(con)
##D 
##D rs <- dbSendQuery(con, query.sql)
##D dbGetStatement(rs)
##D dbHasCompleted(rs)
##D 
##D info <- dbGetInfo(rs)
##D names(dbGetInfo(drv))  
##D 
##D # DBIConnection info
##D names(dbGetInfo(con))
##D 
##D # DBIResult info
##D names(dbGetInfo(rs)) 
## End(Not run)



