### Name: MySQLConnection-class
### Title: Class MySQLConnection
### Aliases: MySQLConnection-class
### Keywords: database interface classes

### ** Examples
## Not run: 
##D drv <- dbDriver("MySQL)
##D con <- dbConnect(drv, dbname = "rsdbi.db")
## End(Not run)



