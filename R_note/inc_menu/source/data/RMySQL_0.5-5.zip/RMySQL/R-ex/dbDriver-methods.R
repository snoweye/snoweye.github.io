### Name: dbDriver-methods
### Title: MySQL implementation of the Database Interface (DBI) classes and
###   drivers
### Aliases: dbDriver-methods dbUnloadDriver-methods
###   dbDriver,character-method dbUnloadDriver,MySQLDriver-method
### Keywords: interface interface database

### ** Examples
## Not run: 
##D # create an MySQL instance and set 10000 of rows per fetch.
##D m <- dbDriver("MySQL", fetch.default.records=10000)
##D 
##D con <- dbConnect(m, username="usr", password = "pwd",
##D            dbname = "iptraffic")
##D rs <- dbSubmitQuery(con, 
##D          "select * from HTTP_ACCESS where IP_ADDRESS = '127.0.0.1'")
##D df <- fetch(rs, n = 50)
##D df2 <- fetch(rs, n = -1)
##D dbClearResult(rs)
##D 
##D pcon <- dbConnect(p, group = "wireless")
##D dbListTables(pcon)
## End(Not run)



