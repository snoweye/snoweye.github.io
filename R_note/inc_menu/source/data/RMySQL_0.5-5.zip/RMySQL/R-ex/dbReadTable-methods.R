### Name: dbReadTable-methods
### Title: Convenience functions for Importing/Exporting DBMS tables
### Aliases: dbReadTable-methods dbWriteTable-methods dbExistsTable-methods
###   dbRemoveTable-methods dbReadTable,MySQLConnection,character-method
###   dbWriteTable,MySQLConnection,character,data.frame-method
###   dbExistsTable,MySQLConnection,character-method
###   dbRemoveTable,MySQLConnection,character-method
### Keywords: interface interface database

### ** Examples
## Not run: 
##D conn <- dbConnect("MySQL", group = "wireless")
##D if(dbExistsTable(con, "fuel_frame")){
##D    dbRemoveTable(conn, "fuel_frame")
##D    dbWriteTable(conn, "fuel_frame", fuel.frame)
##D }
##D if(dbExistsTable(conn, "RESULTS")){
##D    dbWriteTable(conn, "RESULTS", results2000, append = T)
##D else
##D    dbWriteTable(conn, "RESULTS", results2000)
##D }
## End(Not run)



