### Name: dbDataType-methods
### Title: Determine the SQL Data Type of an S object
### Aliases: dbDataType dbDataType-methods dbDataType,DBIObject-method
### Keywords: interface interface database

### ** Examples
## Not run: 
##D data(quakes)
##D ora <- dbDriver("MySQL")
##D sql.type <- dbDataType(ora, quakes)
## End(Not run)



