### Name: DBIDriver-class
### Title: Class DBIDriver
### Aliases: DBIDriver-class
### Keywords: classes database interface

### ** Examples
## Not run: 
##D drv <- dbDriver("ODBC")
##D summary(drv)
##D dbListConnections(drv)
## End(Not run)



