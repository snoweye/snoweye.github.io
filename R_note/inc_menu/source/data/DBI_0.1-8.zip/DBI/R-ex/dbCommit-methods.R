### Name: dbCommit-methods
### Title: DBMS Transaction Management
### Aliases: dbCommit dbRollback dbCommit-methods dbRollback-methods
###   dbCommit,DBIConnection-method dbRollback,DBIConnection-method
### Keywords: interface interface database

### ** Examples
## Not run: 
##D ora <- dbDriver("Oracle")
##D con <- dbConnect(ora)
##D rs <- dbSendQuery(con, 
##D       "delete * from PURGE as p where p.wavelength<0.03")
##D if(dbGetInfo(rs, what = "rowsAffected") > 250){
##D   warning("dubious deletion -- rolling back transaction")
##D   dbRollback(con)
##D }
## End(Not run)



