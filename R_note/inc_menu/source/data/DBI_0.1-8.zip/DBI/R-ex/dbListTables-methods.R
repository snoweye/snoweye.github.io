### Name: dbListTables-methods
### Title: List items from a remote DBMS and from objects that implement
###   the database interface DBI.
### Aliases: dbListTables dbListFields dbListConnections dbListResults
###   dbListTables-methods dbListFields-methods dbListConnections-methods
###   dbListResults-methods dbListTables,DBIConnection-method
###   dbListFields,DBIConnection,character-method
###   dbListConnections,DBIDriver-method dbListResults,DBIConnection-method
### Keywords: interface interface database

### ** Examples
## Not run: 
##D drv <- dbDriver("RSQLite")
##D # after working awhile...
##D for(con in dbListConnections(odbc)){
##D    dbGetStatement(dbListResults(con))
##D }
## End(Not run)



