### Name: dbSendQuery-methods
### Title: Execute a statement on a given database connection
### Aliases: dbSendQuery dbGetQuery dbClearResult dbGetException
###   dbSendQuery-methods dbGetQuery-methods dbClearResult-methods
###   dbGetException-methods dbSendQuery,DBIConnection,character-method
###   dbGetQuery,DBIConnection,character-method
###   dbClearResult,DBIResult-method dbGetException,DBIConnection-method
### Keywords: interface interface database

### ** Examples
## Not run: 
##D drv <- dbDriver("MySQL")
##D con <- dbConnect(drv)
##D res <- dbSendQuery(con, "SELECT * from liv25")
##D data <- fetch(res, n = -1)
## End(Not run)



