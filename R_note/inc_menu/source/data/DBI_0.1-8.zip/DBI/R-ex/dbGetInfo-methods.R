### Name: dbGetInfo-methods
### Title: Database interface meta-data
### Aliases: dbGetInfo dbGetDBIVersion dbGetStatement dbGetRowCount
###   dbGetRowsAffected dbColumnInfo dbHasCompleted dbGetInfo-methods
###   dbGetDBIVersion-methods dbGetStatement-methods dbGetRowCount-methods
###   dbGetRowsAffected-methods dbColumnInfo-methods dbHasCompleted-methods
###   dbGetInfo,DBIObject-method dbGetDBIVersion,-method
###   dbGetStatement,DBIResult-method dbGetRowCount,DBIResult-method
###   dbGetRowsAffected,DBIResult-method dbColumnInfo,DBIResult-method
###   dbHasCompleted,DBIResult-method
### Keywords: interface interface database

### ** Examples
## Not run: 
##D drv <- dbDriver("SQLite")
##D con <- dbConnect(drv)
##D 
##D dbListTables(con)
##D 
##D rs <- dbSendQuery(con, query.sql)
##D dbGetStatement(rs)
##D dbHasCompleted(rs)
##D 
##D info <- dbGetInfo(rs)
##D names(dbGetInfo(drv))  
##D 
##D # DBIConnection info
##D names(dbGetInfo(con))
##D 
##D # DBIResult info
##D names(dbGetInfo(rs)) 
## End(Not run)



