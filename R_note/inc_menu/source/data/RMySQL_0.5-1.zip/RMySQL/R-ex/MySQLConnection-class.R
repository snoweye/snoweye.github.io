### Name: MySQLConnection-class
### Title: Class MySQLConnection
### Aliases: MySQLConnection-class
### Keywords: database interface classes

### ** Examples
##Don't run: 
##D drv <- dbDriver("MySQL)
##D con <- dbConnect(drv, dbname = "rsdbi.db")




