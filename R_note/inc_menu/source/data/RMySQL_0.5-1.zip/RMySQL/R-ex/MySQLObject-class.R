### Name: MySQLObject-class
### Title: Class MySQLObject
### Aliases: MySQLObject-class
### Keywords: database interface classes

### ** Examples
##Don't run: 
##D drv <- dbDriver("MySQL")
##D con <- dbConnect(drv, dbname = "rsdbi.db")




