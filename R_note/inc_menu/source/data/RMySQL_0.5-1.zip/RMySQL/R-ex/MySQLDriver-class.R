### Name: MySQLDriver-class
### Title: Class MySQLDriver
### Aliases: MySQLDriver-class
### Keywords: database interface classes

### ** Examples
##Don't run: 
##D drv <- dbDriver("MySQL")
##D con <- dbConnect(drv, "user/password@dbname")




