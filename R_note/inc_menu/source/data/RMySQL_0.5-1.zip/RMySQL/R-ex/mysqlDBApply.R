### Name: mysqlDBApply
### Title: Apply R/S-Plus functions to remote groups of DBMS rows
###   (experimental)
### Aliases: mysqlDBApply
### Keywords: programming interface database

### ** Examples
##Don't run: 
##D ## compute quanitiles for each network agent
##D con <- dbConnect(MySQL(), group="vitalAnalysis")
##D res <- dbSendQuery(con, 
##D              "select Agent, ip_addr, DATA from pseudo_data order by Agent")
##D out <- dbApply(res, INDEX = "Agent", 
##D         FUN = function(x, grp) quantile(x$DATA, names=FALSE))




