### Name: MySQLResult-class
### Title: Class MySQLResult
### Aliases: MySQLResult-class
### Keywords: database interface classes

### ** Examples
##Don't run: 
##D drv <- dbDriver("MySQL")
##D con <- dbConnect(drv, dbname = "rsdbi.db")




