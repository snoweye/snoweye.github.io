### Name: dbApply
### Title: Apply R/S-Plus functions to remote groups of DBMS rows
###   (experimental)
### Aliases: dbApply
### Keywords: programming interface database

### ** Examples
##Don't run: 
##D ## compute quanitiles for each network agent
##D con <- dbConnect(MySQL(), group="vitalAnalysis")
##D rs <- dbSendQuery(con, 
##D              "select Agent, ip_addr, DATA from pseudo_data order by Agent")
##D out <- dbApply(rs, INDEX = "Agent", 
##D         FUN = function(x, grp) quantile(x$DATA, names=FALSE))




