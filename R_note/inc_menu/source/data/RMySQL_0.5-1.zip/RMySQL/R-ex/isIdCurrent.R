### Name: isIdCurrent
### Title: Check whether a database handle object is valid or not
### Aliases: isIdCurrent
### Keywords: interface database

### ** Examples
##Don't run: 
##D cursor <- dbSendQuery(con, sql.statement)
##D isIdCurrent(cursor)




