### Name: dbObjectId-class
### Title: Class dbObjectId
### Aliases: dbObjectId-class
### Keywords: classes interface database

### ** Examples
##Don't run: 
##D   pg <- dbDriver("PostgreSQL")
##D   con <- dbConnect(pg, "user", "password")
##D   is(pg, "dbObjectId")   ## True
##D   is(con, "dbObjectId")  ## True
##D   isIdCurrent(con)       ## True
##D   q("yes")
##D   \$ R 
##D   isIdCurrent(con)       ## False




