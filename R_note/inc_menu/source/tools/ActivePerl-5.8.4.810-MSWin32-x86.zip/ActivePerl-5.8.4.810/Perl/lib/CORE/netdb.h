/* netdb.h */

/* djl */
/* Provide UNIX compatibility */


#ifndef  _INC_NETDB
#define  _INC_NETDB

#include <sys/socket.h>

#endif /* _INC_NETDB */
