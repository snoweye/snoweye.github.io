print "Hello from ActivePerl!";
