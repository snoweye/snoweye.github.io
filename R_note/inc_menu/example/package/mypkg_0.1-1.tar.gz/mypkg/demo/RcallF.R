a <- 1 : 9

test.f(a)
