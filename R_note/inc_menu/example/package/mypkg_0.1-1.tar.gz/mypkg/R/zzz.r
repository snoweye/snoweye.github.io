.First.lib <- function(lib, pkg)
{
    library.dynam("mypkg", pkg, lib)
}

