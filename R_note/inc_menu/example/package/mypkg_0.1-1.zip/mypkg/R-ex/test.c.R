### Name: test.c
### Title: mypkg test.c
### Aliases: test.c
### Keywords: misc

### ** Examples


a<-1:9
test.c(a)




