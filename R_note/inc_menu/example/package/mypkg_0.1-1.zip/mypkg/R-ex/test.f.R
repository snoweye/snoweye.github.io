### Name: test.f
### Title: mypkg test.f
### Aliases: test.f
### Keywords: misc

### ** Examples


a<-1:9
test.f(a)




