/* This file contains some tool functions required by other functions
   R_*() in "src/R_*.c".

   Writen: Wei-Chen Chen on 2008/03/30.
*/

#include<R.h>

/* Allocate a 2d pointer array with double precision. */
double** allocate_double_array(int n){
  double **pointerarray = (double **) malloc(n * sizeof(double *));
  if(pointerarray == NULL){
    Rprintf("Memory allocation fails!\n");
    exit(1);
  }
  return(pointerarray);
} /* End of double** allocate_double_array(). */


/* Allocate a 3d pointer array with double precision. */
double*** allocate_3d_array(int n, int n2){
  int i;
  double ***pointerarray = (double ***) malloc(n * sizeof(double *));
  for(i = 0; i < n; i++){
    pointerarray[i] = allocate_double_array(n2);
  }
  if(pointerarray == NULL){
    Rprintf("Memory allocation fails!\n");
    exit(1);
  }
  return(pointerarray);
} /* End of double*** allocate_3d_array(). */


/* Free a 3d pointer array. */
void free_3d_array(double ***pointerarray, int n){
  int i;
  for(i = 0; i < n; i++){
    free(pointerarray[i]);
  }
  free(pointerarray);
}
