/* This function contains all function for testing C Points. */

#include <R.h>

void test_1d(double *X, int *d1){
  int i;
  double *a, b[*d1];

  Rprintf("Print directly\n");
  for(i = 0; i < *d1; i++){
    Rprintf("%f ", X[i]);
    b[i] = X[i];
  }   
  Rprintf("\n");

  Rprintf("\nPrint from a copy\n");
  for(i = 0; i < *d1; i++){
    Rprintf("%f ", b[i]);
  }   
  Rprintf("\n");

  a = X;
  Rprintf("\nPrint from an assigned pointer\n");
  for(i = 0; i < *d1; i++){
    Rprintf("%f ", *a);
    a++;
  }   
  Rprintf("\n");
}
