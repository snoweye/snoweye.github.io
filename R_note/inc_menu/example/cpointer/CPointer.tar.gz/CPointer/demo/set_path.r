rm(list = ls(all.names = TRUE))

sourceDir <- function(path, trace = TRUE, ...) {
  nm <- list.files(path, pattern = ".rda$")
  if(length(nm) > 0){
    for(i in 1:length(nm)){
      if(trace) cat(nm[i], " ")
      load(file.path(path, nm[i]), .GlobalEnv)
      if(trace & i %% 5 == 0) cat("\n")
    }
    if(trace) cat("\n")
  }

  nm <- list.files(path, pattern = ".[Rr]$")
  if(length(nm) > 0){
    for(i in 1:length(nm)){
      if(trace) cat(nm[i], " ")
      source(file.path(path, nm[i]), ...)
      if(trace & i %% 5 == 0) cat("\n")
    }
    if(trace) cat("\n")
  }
}

# sourceDir("./data")
sourceDir("./R")

# package.skeleton(name = "CPointer", list = ls())

lib.name <- "./src/CPointer.dll"
dyn.load(lib.name)
# dyn.unload(lib.name)

.load <- function() dyn.load(lib.name)
.unload <- function() dyn.unload(lib.name)
