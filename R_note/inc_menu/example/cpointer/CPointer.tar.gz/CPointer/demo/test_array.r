
(X <- 1:12)
test.1d(X)

(X.2 <- matrix(X, ncol = 2))
test.2d(X.2)

(X.3 <- array(X, dim = c(2, 2, 3)))
test.3d(X.3)
