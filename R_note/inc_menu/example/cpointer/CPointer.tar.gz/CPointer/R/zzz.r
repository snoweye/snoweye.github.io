.First.lib <- function(lib, pkg)
{
  library.dynam("CPointer", pkg, lib)
}

.Last.lib <- function(lib, pkg)
{
  library.dynam.unload("Pointer", pkg, lib)

  for(i in load.lib){
    pos <- match(paste("package:", i, sep = ""), search())
    if(! is.na(pos)){
      detach(pos = pos)
    }
  }
}

