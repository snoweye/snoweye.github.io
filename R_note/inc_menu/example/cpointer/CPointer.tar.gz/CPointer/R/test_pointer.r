### This function contains function to call C.

test.1d <- function(X){
  .C("test_1d", X = as.double(X), d1 = as.integer(length(X)))
  invisible()
}

test.2d <- function(X){
  X <- t(X)
  .C("test_2d", X = as.double(X), d1 = as.integer(ncol(X)),
                d2 = as.integer(nrow(X)))
  invisible()
}

test.3d <- function(X){
  X <- aperm(X, c(2, 1, 3))
  X.dim <- dim(X)
  .C("test_3d", X = as.double(X), d1 = as.integer(X.dim[3]),
                d2 = as.integer(X.dim[2]), d3 = as.integer(X.dim[1]))
  invisible()
}
