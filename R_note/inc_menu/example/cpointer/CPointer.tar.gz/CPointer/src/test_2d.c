/* This function contains all function for testing C Points. */

#include <R.h>

double** allocate_double_array(int n);

void test_2d(double *X, int *d1, int *d2){
  int i, j, k = 0;
  double *a, b[*d1][*d2], **c;

  c = allocate_double_array(*d1);

  Rprintf("Print directly\n");
  for(i = 0; i < *d1; i++){
    c[i] = &X[k];
    for(j = 0; j < *d2; j++){
      Rprintf("%f ", X[k]);
      b[i][j] = X[k++];
    }
    Rprintf("\n");
  }   

  Rprintf("\nPrint from a copy\n");
  for(i = 0; i < *d1; i++){
    for(j = 0; j < *d2; j++){
      Rprintf("%f ", b[i][j]);
    }
    Rprintf("\n");
  }   

  a = X;
  Rprintf("\nPrint from an assigned pointer (C: last index goes first)\n");
  for(i = 0; i < *d1 * *d2; i++){
    Rprintf("%f ", *a);
    a++;
  }   
  Rprintf("\n");

  Rprintf("\nPrintf from an double array\n");
  for(i = 0; i < *d1; i++){
    for(j = 0; j < *d2; j++){
      Rprintf("%f ", c[i][j]);
    }
    Rprintf("\n");
  }   

  free(c);
}

