/* This function contains all function for testing C Points. */

#include <R.h>

double*** allocate_3d_array(int n, int n2);
void free_3d_array(double ***pointerarray, int n);

void test_3d(double *X, int *d1, int *d2, int *d3){
  int i, j, k, m = 0;
  double *a, b[*d1][*d2][*d3], ***c;

  c = allocate_3d_array(*d1, *d2);

  Rprintf("Print directly\n");
  for(i = 0; i < *d1; i++){
    for(j = 0; j < *d2; j++){
      c[i][j] = &X[m];
      for(k = 0; k < *d3; k++){
        Rprintf("%f ", X[m]);
        b[i][j][k] = X[m++];
      }
      Rprintf("\n");
    }
    Rprintf("---\n");
  }   

  Rprintf("\nPrint from a copy\n");
  for(i = 0; i < *d1; i++){
    for(j = 0; j < *d2; j++){
      for(k = 0; k < *d3; k++){
        Rprintf("%f ", b[i][j][k]);
      }
      Rprintf("\n");
    }
    Rprintf("---\n");
  }   
  Rprintf("\n");

  a = X;
  Rprintf("Print from an assigned pointer (C: last index goes first)\n");
  for(i = 0; i < *d1 * *d2 * *d3; i++){
    Rprintf("%f ", *a);
    a++;
  }   

  Rprintf("\nPrintf from an 3d array\n");
  for(i = 0; i < *d1; i++){
    for(j = 0; j < *d2; j++){
      for(k = 0; k < *d3; k++){
        Rprintf("%f ", c[i][j][k]);
      }
      Rprintf("\n");
    }
    Rprintf("---\n");
  }   

  free_3d_array(c, *d1);
}
