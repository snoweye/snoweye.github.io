### MCMC for the GLMM model of Deer Ecervi L1 data set.

rm(list = ls())
source("u0-deer.r")         # Load data.
source("u5-ml_glmm.r")      # Load library and utility.

### Setup initial step.
da.ml <- get.ml.initial(da)

### Setup options for constrOptim().
theta <- c(da.ml$fixed, da.ml$sd.random)
total.mar.logL <- function(theta){
  logL <- 0
  for(i.deer in 1:nrow(da)){
    logL <- logL + mar.logL(i.deer, theta)
  }
  -logL
} # End of total.mar.logL().
ui <- matrix(c(rep(0, length(da.ml$fixed)), 1), nrow = 1)
ci <- 0

constrOptim(theta, total.mar.logL, NULL,
            ui, ci, method = "Nelder-Mead")
