library(nlme)
library(MASS)

get.ml.initial <- function(da){
  m.glmm <- glmmPQL(Y ~ Length * Sex, random = ~ 1 | Farm,
                    family = binomial, data = da, verbose = FALSE)
  ret <- list(y = da$Y,
              X = cbind(1, da$Length, da$Sex, da$Length * da$Sex),
              fixed = m.glmm$coefficients$fixed,
              sd.random = as.numeric(VarCorr(m.glmm)[1, 2]))
  ret
} # End of get.ml.initial().


### Marginal loglikelihood for the i-th deer given
### theta = c(4 fixed effects, sd.random).
mar.logL <- function(i.deer, theta){
  f <- function(x){
    num <- exp(sum(da.ml$X[i.deer,] * theta[-length(theta)]) + x)
    P <- num / (1 + num)
    ret <- da.ml$y[i.deer] * log(P) + (1 - da.ml$y[i.deer]) * log(1 - P) +
           dnorm(x, mean = 0, sd = theta[length(theta)], log = TRUE)
    ret <- exp(ret)
    ret
  } # End of f().

  ret <- integrate(f, -20, 20)
  log(ret$value)
} # End of mar.lik().
